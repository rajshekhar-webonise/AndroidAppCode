<?php
	include_once("db.php");
	mysqli_query($conn,"SET NAMES utf8");
	$Flag=$_POST["Flag"];
	$ward12Array = array();
	if($Flag == "searchAll") {
		$SECTION_NO= $_POST["SECTION_NO"];
		$FM_NAMEEN = $_POST["FM_NAMEEN"];
		$LASTNAMEEN = $_POST["LASTNAMEEN"];
		$IDCARD_NO = $_POST["IDCARD_NO"];
		$FROM_AGE = $_POST["FROM_AGE"];
		$TO_AGE = $_POST["TO_AGE"];
		if($FROM_AGE == 0 or $TO_AGE == 0){
		$str = "select SECTION_NO,CadId ,mobileno,  fm_name_v1 ,  Lastname_v1 ,FM_NAMEEN,LASTNAMEEN,IDCARD_NO ,  SEX ,  AGE 
		from ward12 where FM_NAMEEN like '%$FM_NAMEEN%' or LASTNAMEEN like '%$LASTNAMEEN%' or IDCARD_NO like '%$IDCARD_NO%' and SECTION_NO='$SECTION_NO'";
		$str1 = "select SECTION_NO,CadId ,mobileno,  fm_name_v1 ,  Lastname_v1 ,FM_NAMEEN,LASTNAMEEN,IDCARD_NO ,  SEX ,  AGE
		from ward12 where SECTION_NO='$SECTION_NO' and FM_NAMEEN like '%$FM_NAMEEN%'
		and LASTNAMEEN like '%$LASTNAMEEN%' and IDCARD_NO like '%$IDCARD_NO%'";
		}
		else{
				$str = "select SECTION_NO,CadId ,mobileno,  fm_name_v1 ,  Lastname_v1 ,FM_NAMEEN,LASTNAMEEN,IDCARD_NO ,  SEX ,  AGE 
		from ward12 where FM_NAMEEN like '%$FM_NAMEEN%' or LASTNAMEEN like '%$LASTNAMEEN%' or IDCARD_NO like '%$IDCARD_NO%' and SECTION_NO='$SECTION_NO'";
		$str1 = "select SECTION_NO,CadId ,mobileno,  fm_name_v1 ,  Lastname_v1 ,FM_NAMEEN,LASTNAMEEN,IDCARD_NO ,  SEX ,  AGE
		from ward12 where SECTION_NO='$SECTION_NO' and FM_NAMEEN like '%$FM_NAMEEN%'
		and LASTNAMEEN like '%$LASTNAMEEN%' and IDCARD_NO like '%$IDCARD_NO%' and AGE BETWEEN $FROM_AGE and $TO_AGE";

		}
		$query=mysqli_query($conn,$str1);
        $totalRows = $query->num_rows;
		if($totalRows > 0)
                {
               	echo "<table id='showDataTable' class='table table-striped table-bordered dt-responsive nowrap' cellspacing='0' width='100%'>
			<thead>
				<tr class='text-center'>
                    <th></th>                           
					<th>First Name</th>			<th>Last Name</th>
					<th>IDCARD_NO</th>			<th>SEX</th>
					<th>AGE</th>	   
					<th>Mobile No</th>
				</tr>
			</thead>
			<tfoot>
				<tr class='text-center'>    <th></th>                         
					<th>fm_name_v1</th>			<th>Lastname_v1</th>
					<th>IDCARD_NO</th>			<th>SEX</th>
					<th>AGE</th>	          		
					<th>mobileno</th>					
				</tr>
			</tfoot><tbody>";
			    while($row = $query->fetch_array()) {
					$ward12Array[] = $row; 
					$CadId =$row["CadId"];
					$FIRSTNAME = $row["FM_NAMEEN"];
					$LASTNAME = $row["LASTNAMEEN"];       
					$fm_name_v1 =$row["fm_name_v1"];
					$Lastname_v1 = $row["Lastname_v1"];
					$IDCARD_NO = $row["IDCARD_NO"];
					$SEX = $row["SEX"];
					$AGE = $row["AGE"];
					$mobileno = $row["mobileno"];
				echo "<tr>
					 <td  onclick='show($CadId,$SECTION_NO)'>
						<i class='glyphicon glyphicon-tag showClass' style='color:blue;display:block;'></i>
					 </td>	
					<td class='fm_name_v1$CadId disableClass'>$fm_name_v1</td>
					<td class='Lastname_v1$CadId disableClass'>$Lastname_v1</td>
                    <td class='IDCARD_NO$CadId'>$IDCARD_NO</td>
					<td class='SEX$CadId'>$SEX</td>
					<td class='AGE$CadId'>$AGE</td>
					<td class='mobileno$CadId'>$mobileno</td>
					</tr>";
			}
			echo "</tbody></table>";	
		}
		else {
			echo "<h4>Sorry, No Records Founds Search Again</h4>";
		}
	}
	else if($Flag == "loadAllSectionNames") {
		$query=mysqli_query($conn,"select distinct SECTION_NO,SECTION_NAME_V1 from sectionData ");
        $totalRows = $query->num_rows;
        // echo $totalRows;
		if($totalRows > 0) {
			echo "<option>Select Section</option>";
			while($row = $query->fetch_array()) {
				$SECTION_NO = $row["SECTION_NO"];
				$SECTION_NAME_V1 = $row["SECTION_NAME_V1"];
				echo "<option value='$SECTION_NO'>$SECTION_NAME_V1</option>";
			}
		}
	}
	else if($Flag == "loadAllDistinctSectionNames") {
		$query=mysqli_query($conn,"select distinct SECTION_NO,SECTION_NAME_V1 from sectionData ");
        $totalRows = $query->num_rows;
        // echo $totalRows;
		if($totalRows > 0) {
			echo "<option>Select Section</option>";
			while($row = $query->fetch_array()) {
				$SECTION_NO = $row["SECTION_NO"];
				$SECTION_NAME_V1 = $row["SECTION_NAME_V1"];
				echo "<option value='$SECTION_NO'>$SECTION_NAME_V1</option>";
			}
		}
	}
	else if($Flag == "saveData"){
		$CadId = $_POST["CadId"];
		$mobileno = $_POST["mobileno"];
		$query = "update ward12 set mobileno=$mobileno where CadId=$CadId";
		if(mysqli_query($conn,$query)){
			echo "Updated given details";
		}else{
			echo mysqli_error($conn);
		}
	}
	else if($Flag=="showData") {
		$query=mysqli_query($conn,"select distinct(SECTION_NO) , CadId ,mobileno,  fm_name_v1 ,  Lastname_v1 ,FM_NAMEEN,LASTNAMEEN,IDCARD_NO ,  SEX ,  AGE 
		from ward12");
	    $totalRows = $query->num_rows;
        // echo $totalRows;
		if($totalRows > 0)
                {
               	echo "<table id='showDataTable' class='table table-striped table-bordered dt-responsive nowrap' cellspacing='0' width='100%'>
			<thead>
				<tr class='text-center'>
                    <th></th>                           
					<th>First Name</th>			<th>Last Name</th>
					<th>IDCARD_NO</th>			<th>SEX</th>
					<th>AGE</th>	      
					<th>Mobile No</th>
				</tr>
			</thead>
			<tfoot>
				<tr class='text-center'>    <th></th>                         
					<th>fm_name_v1</th>			<th>Lastname_v1</th>
					<th>IDCARD_NO</th>			<th>SEX</th>
					<th>AGE</th>	      
					<th>mobileno</th>					
				</tr>
			</tfoot><tbody>";
			    while($row = $query->fetch_array()) {
					$ward12Array[] = $row; 
					$CadId =$row["CadId"];
					$FIRSTNAME = $row["FM_NAMEEN"];
					$LASTNAME = $row["LASTNAMEEN"];       
					$fm_name_v1 =$row["fm_name_v1"];
					$Lastname_v1 = $row["Lastname_v1"];
					$IDCARD_NO = $row["IDCARD_NO"];
					$SEX = $row["SEX"];
					$AGE = $row["AGE"];
					$mobileno = $row["mobileno"];
					$SECTION_NO = $row["SECTION_NO"];
				echo "<tr>
					 <td  onclick='show($CadId,$SECTION_NO)'>
						<i class='glyphicon glyphicon-tag showClass' style='color:blue;display:block;'></i>
					 </td>	
					<td class='fm_name_v1$CadId disableClass'>$fm_name_v1</td>
					<td class='Lastname_v1$CadId disableClass'>$Lastname_v1</td>
                    <td class='IDCARD_NO$CadId'>$IDCARD_NO</td>
					<td class='SEX$CadId'>$SEX</td>
					<td class='AGE$CadId'>$AGE</td>
					<td class='mobileno$CadId'>$mobileno</td></tr>";
			}
			echo "</tbody></table>";	
		}
	}
	else if($Flag == 'showCandidate'){
		$CadId = $_POST["CadId"];
		echo count($ward12Array);
	}
	else if($Flag=="searchResult"){
		$text = $_POST["text"];
		$column = $_POST["col"];
		if($column == '0')
		{
				$query1 = "select CadId,HOUSE_NO_V1,HOUSENO_V1,HOUSE_NO_EN,fm_name_v1,Lastname_v1,FM_NAMEEN,LASTNAMEEN,RLN_FM_NMEN,RLN_L_NMEN
		from ward12 where CadId LIKE '%$text%' or HOUSE_NO_V1 LIKE '%$text%' or HOUSENO_V1 LIKE '%$text%' or HOUSE_NO_EN LIKE '%$text%' or 
		fm_name_v1 LIKE '%$text%' or Lastname_v1 LIKE '%$text%' or FM_NAMEEN LIKE '%$text%' or LASTNAMEEN LIKE '%$text%' or RLN_FM_NMEN
		LIKE '%$text%' or RLN_L_NMEN LIKE '%$text%' or DOB LIKE '%$text%'";
		} else {
			$query1 = "select CadId,HOUSE_NO_V1,HOUSENO_V1,HOUSE_NO_EN,fm_name_v1,Lastname_v1,FM_NAMEEN,LASTNAMEEN,RLN_FM_NMEN,RLN_L_NMEN,DOB
			from ward12 where $column LIKE '%$text%'";
		}
		$query = mysql_query($query1);
		if(mysql_num_rows($query) > 0){
			echo "<table id='showDataTable' class='table table-bordered table-responsive table-striped table-condensed'>
			<thead>
				<tr><th>CadId</th>
					<th>HOUSE_NO_V1</th>			<th>HOUSENO_V1</th>
					<th>HOUSE_NO_EN</th>			<th>fm_name_v1</th>
					<th>Lastname_v1</th>			<th>FM_NAMEEN</th>
					<th>LASTNAMEEN</th>			<th>RLN_FM_NMEN</th>
					<th>RLN_L_NMEN</th>			<th>DOB</th>
				</tr>
			</thead>
			<tfoot>
				<tr><th>CadId</th>
					<th>HOUSE_NO_V1</th>			<th>HOUSENO_V1</th>
					<th>HOUSE_NO_EN</th>			<th>fm_name_v1</th>
					<th>Lastname_v1</th>			<th>FM_NAMEEN</th>
					<th>LASTNAMEEN</th>			<th>RLN_FM_NMEN</th>
					<th>RLN_L_NMEN</th>			<th>DOB</th>
				</tr>
			</tfoot><tbody>";
			while($row = mysql_fetch_array($query)){
				$CadId =$row["CadId"];
				$HOUSE_NO_V1 = $row["HOUSE_NO_V1"];
				$HOUSENO_V1 = $row["HOUSENO_V1"];
				$HOUSE_NO_EN =$row["HOUSE_NO_EN"];
				$fm_name_v1 = $row["fm_name_v1"];
				$Lastname_v1 = $row["Lastname_v1"];
				$FM_NAMEEN = $row["FM_NAMEEN"];
				$LASTNAMEEN = $row["LASTNAMEEN"];
				$RLN_FM_NMEN = $row["RLN_FM_NMEN"];
				$RLN_L_NMEN = $row["RLN_L_NMEN"];	
				$DOB = $row["DOB"];
				echo "<tr> <td>$CadId</td>
				<td>$HOUSE_NO_V1</td>				<td>$HOUSENO_V1</td>
				<td>$HOUSE_NO_EN</td>				<td>$fm_name_v1</td>
				<td>$Lastname_v1</td>				<td>$FM_NAMEEN</td>
				<td>$LASTNAMEEN</td>				<td>$RLN_FM_NMEN</td>
				<td>$RLN_L_NMEN</td>				<td>$DOB</td></tr>";
			}
			echo "</tbody></table>";	
		}
	}
?>
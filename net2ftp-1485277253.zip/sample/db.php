<?php

	$servername = "mysql.hostinger.in";
	$username = "u477773763_demo1";
	$password = "budharam23";
	$dbname = "u477773763_demo1";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
       
?>
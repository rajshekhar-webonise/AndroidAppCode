<?php 
    require_once('db.php');
	$fullname = $_REQUEST['fullname'];
	$DOB = $_REQUEST['DOB'];
	$username = $_REQUEST['username'];   
	$password = $_REQUEST['password'];
	$confirmPassword = $_REQUEST['confpassword'];
	$sql = "insert into register (fullname,DOB,username,password,confpassword) values 
	('$fullname','$DOB','$username','$password','$confirmPassword')"; 
	//Executing query to database
	if(mysqli_query($conn,$sql)){
		echo 'success';
	}else{
		echo mysqli_error($conn);
	}
	mysqli_close($conn);
?>
<?php
        include_once('db.php');
	$Flag = $_GET['Flag'];
	if($Flag == 'lastname'){
		$sql = "SELECT LASTNAMEEN FROM ward12 
				WHERE LASTNAMEEN LIKE '%".$_GET['query']."%'
				LIMIT 20"; 
		$result = mysqli_query($conn,$sql);
		echo mysqli_error($conn);
		$json = array();
		while($row = $result->fetch_assoc()){
			 $json[] = $row['LASTNAMEEN'];
		}

		echo json_encode($json);
	}
	else if($Flag == 'firstname'){
		$sql = "SELECT FM_NAMEEN FROM ward12 
				WHERE FM_NAMEEN LIKE '%".$_GET['query']."%'
				LIMIT 20"; 
		$result = mysqli_query($conn,$sql);
		echo mysqli_error($conn);
		$json = array();
		while($row = $result->fetch_assoc()){
			 $json[] = $row['FM_NAMEEN'];
		}

		echo json_encode($json);
	}
	
?>
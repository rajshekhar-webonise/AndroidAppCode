<?php
	include_once("db.php");
	$first_name = $_POST["first_name"];
	$last_name = $_POST["last_name"];
	$comment = $_POST["comment"];
	$sql = "insert into feedback (first_name,last_name,comment) values ('$first_name','$last_name','$comment')"; 
	if(mysqli_query($conn,$sql)){
		echo 'Feedback Submitted Successfully';
		echo "<a href='menu.html' style='margin:20px;font-weight:bold;color:#3c3c3c;'>Back</a>";
	}else{
		echo mysqli_error($conn);
	}
	mysqli_close($conn);
?>
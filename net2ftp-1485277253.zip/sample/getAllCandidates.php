<?php 
      	 require_once('db.php');
         header('Content-Type: application/json; charset=utf-8');
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Getting values
		$username = $_POST['username'];
		$password = $_POST['password'];
         
        $result = mysqli_query($conn,"SELECT `CadId` ,  `fm_name_v1` ,  `Lastname_v1` ,  `RLN_TYPE` ,  `RLN_FM_NM_v1` ,  `RLN_L_NM_v1` ,  `IDCARD_NO`  FROM candidates where CadId=1"); 
        $totalRows = $result->num_rows;
		//Executing query to database
		$arr = array();
		if ($totalRows > 0) {
		   while($row = $result->fetch_assoc()) 
                   {
			$arr[] = $row;
		   }
        	} else {
		     echo mysqli_error($conn);
            	}
                echo json_encode($arr); 
		
		//Closing the database 
		mysqli_close($conn); 

	}
?>						
<?php
    require_once('db.php');
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];     

   	$result = mysqli_query($conn,"SELECT * FROM register WHERE username ='$username' and password =
	'$password'");
	$totalRows = $result->num_rows;
   	//Executing query to database
	if($totalRows > 0 )
	{
	        echo "success-$username"; 
  	}
	else
	{
		echo mysqli_error($conn);
	}
?>			
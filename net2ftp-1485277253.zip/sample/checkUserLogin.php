<?php
      	 require_once('db.php');
         $Flag = $_POST['Flag'];
		 session_start();
		if($Flag == 'logout'){
			$_SESSION=array();
			session_regenerate_id(); 
			session_destroy();
		}
         else if($Flag == 'login')
         {
            $username = $_POST['username'];
			$password = $_POST['password'];     
            $result = mysqli_query($conn,"SELECT * FROM register WHERE username ='$username' and password =
			'$password'");
            $totalRows = $result->num_rows;
			//Executing query to database
			if($totalRows > 0 )
			{
				echo "success";
                                $_SESSION["username"] = $username; 
			}
			else
			{
				echo mysqli_error($conn);
			}
	}
?>
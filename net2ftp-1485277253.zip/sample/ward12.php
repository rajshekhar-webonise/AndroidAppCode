<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8;">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" href="datatables/dataTables.bootstrap.min.css"/>
		<link rel="stylesheet" href="datatables/jquery.dataTables.min.css"/>
		<link rel="stylesheet" href="datatables/responsive.bootstrap.min.css"/>
		<link rel="stylesheet" href="datatables/buttons.dataTables.min.css"/>
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="datatables/jquery.dataTables.js"></script>
		<script type="text/javascript" src="datatables/dataTables.buttons.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="datatables/dataTables.bootstrap.js"></script>
		<script type="text/javascript" src="datatables/responsive.bootstrap.min.js"></script>
		<script type="text/javascript" src="datatables/dataTables.responsive.min.js"></script>
		<script type="text/javascript" src="datatables/buttons.print.min.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
		<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
		<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
		<script src="js/bootstrap3-typeahead.min.js"></script>
		<style>
	      	#showDataTable td,#showDataTable th{
				margin:4px;
				padding:4px;
				text-align:center;
			}
			.titlePage{
				margin:20px 0;
			}
			#loaderWrapper{
			 width:150px;
			 height:150px;
			 margin:auto;
			}
			.loader {
			  border: 16px solid #f3f3f3;
			  border-radius: 50%;
			  border-top: 16px solid #3498db;
			  width: 120px;
			  margin:100px auto;
			  height: 120px;
			  -webkit-animation: spin 2s linear infinite;
			  animation: spin 2s linear infinite;
			}

			@-webkit-keyframes spin {
			  0% { -webkit-transform: rotate(0deg); }
			  100% { -webkit-transform: rotate(360deg); }
			}

			@keyframes spin {
			  0% { transform: rotate(0deg); }
			  100% { transform: rotate(360deg); }
			}
			.modeless {
				top:10%;
				left:50%;
				bottom:auto;
				right:auto;
				margin-left:-300px;
			}
			h4{
				display:flex;
				margin:80px auto;
			}
			#searchDiv {
				width:90%;
				margin:0 auto;
			}
                        .glyphicon {
                             padding:4px;
                        }   
		</style>
		<script type="text/javascript">


		</script>		
		<script>
			var timeout;
			var data;
			function searchAll() {
				$("#myModalFilter").modal('hide');
				$('#showDataDiv').html("");	
				$(".loader").css("display","block");
				$.post("ward12Operation.php",
				{
					Flag:"searchAll",
					SECTION_NO:$("#txtSectionName").val(),
					FROM_AGE:$("#txtAGEFROM").val(),
					TO_AGE:$("#txtAGETO").val(),
					FM_NAMEEN:$("#txtFirstName").val(),
					LASTNAMEEN:$("#txtLastName").val(),
					IDCARD_NO:$("#txtVoterId").val()
				},function(data) {
					$("#searchDiv").css("display","none");
					$(".loader").css("display","none");
					$('#showDataDiv').html(data);	
					applyDataTable();
				});
			}
			function loadAllSectionNames(){
				$.post("ward12Operation.php",
				{
					Flag:"loadAllSectionNames"
				},function(data) {
					$("#txtSectionName").html(data);
				});			
			}
			function loadAllDistinctSectionNames(){
				$.post("ward12Operation.php",
				{
					Flag:"loadAllDistinctSectionNames"
				},function(data) {
					$("#modalSectionName").html(data);
				});			
			}			
			function showAllData() {
 				$.post("ward12Operation.php",
				{
					Flag:"showData"
				},function(data,success)
				{
					data = data;
					$(".loader").css("display","none");
          	  	    $('#showDataDiv').html(data);	
					applyDataTable();
                    $("marquee").css('display','block');
				});
			}
			$(document).ready(function()
			{

			$('#txtLastName').typeahead({
				source:  function (query, process) {
				return $.get('searchLastName.php', { Flag:"lastname",query: query }, function (data) {
						console.log(data);
						data = $.parseJSON(data);
						return process(data);
					});
				}
			});
			$('#txtFirstName').typeahead({
				source:  function (query, process) {
				return $.get('searchLastName.php', { Flag:"firstname",query: query }, function (data) {
						console.log(data);		
						data = $.parseJSON(data);
						return process(data);
					});
				}
			});
				$("#openSearchDiv").click(function(){
					$("#searchDiv").animate({
						height: 'toggle'
					},'slow');
					//$("#example_wrapper").css("display","none");
				});
				loadAllSectionNames();
				loadAllDistinctSectionNames();
				$("#btnFilter").click(function(){
					//$("#myModalFilter").modal('show');
				});
				$("#txtSaveFilter").click(function(){
					searchAll();
				});
				showAllData();
				$("#modalSave").click(function(){
					if($("#modalContact").val().length != 10){
						alert("Please enter correct mobile no");
					}
					else{
						$.post("ward12Operation.php",
						{
							Flag:"saveData",
							CadId:$("#txtCadId").val(),
							mobileno:$("#modalContact").val()
						},function(data,success)
						{
							//alert(data);
							showAllData();
						});
					}
				});
				
				$("#selectField").keyup(function() {
					applyDataTable();
				});
			});
			function applyDataTable()
			{
					$('#showDataTable tfoot th').each( function () {
					var title = $('#showDataTable thead th').eq( $(this).index() ).text();
					$(this).index() === 0 ? null : $(this).html( '<input type="text" size="12"  placeholder="Search '+title+'" />' );
				} );
			  
				// DataTable
				var table = $('#showDataTable').DataTable( {
					colReorder: true,
				/*	dom: 'Bfrtip',
					buttons: [
						'copyHtml5',
						'excelHtml5',
						'csvHtml5',
						'pdfHtml5'
					] */
				} );
				// Apply the filter
				$("#showDataTable tfoot input").on( 'keyup change', function () {
					table
						.column( $(this).parent().index()+':visible' )
						.search( this.value )
						.draw();
				} );
			$("#txtSearchField").on("keyup",function(){
				table.columns($("#selectField").val()).search(this.value).draw();
			});	
		 }
			function searchResult(text,col) {
				$.post("ward12Operation.php",
				{
					Flag:"searchResult",
					text:text,
					col:col
				},function(data,success)
				{
					$("#showDataDiv").html(data);
					$("#showDataTable").DataTable();
				});
			}
			function reload(){
				var rrr = $("#showDataDiv").DataTable({
					ajax:data
				});
				rrr.ajax.reload();
			}
			function showCandidate(CadId) {
				$.post("ward12Operation.php",
				{
					Flag:"showCandidate",
					CadId:CadId
				},function(data,success)
				{
					//alert(data);
					$("#showCandidateData").html(data);
					$("#myCandidateModal").modal('show');
				});
			}
			function logout(){
				$.post("checkUserLogin.php",
				{
					Flag:"logout"
				},function(data,success)
				{
					window.location.reload();
				});				
			}
			function show(CadId,SECTION_NO) {
			//	alert(SECTION_NO);
				$("#txtCadId").val(CadId);
				var $row = $('.showClass').closest("tr");    // Find the row
				var clsNamefm_name_v1 = "fm_name_v1" + CadId;
				var clsNameLastname_v1 = "Lastname_v1" + CadId;
				var clsNameIDCARD_NO = "IDCARD_NO" + CadId;
				var clsNameSEX = "SEX" + CadId;
				var clsNameAGE = "AGE" + CadId;
				var clsNameDOB = "DOB" + CadId;
				var clsmobileno = "mobileno" + CadId;	
				var clsSectionName = "sectionName" + CadId;	
				var $text1 = $row.find("."+clsNamefm_name_v1).text(); // Find the text
				var $text2 = $row.find("."+clsNameLastname_v1).text(); // Find the text
				var $text3 = $row.find("."+clsNameIDCARD_NO).text(); // Find the text
				var $text4 = $row.find("."+clsNameSEX).text(); // Find the text
				var $text5 = $row.find("."+clsNameAGE).text(); // Find the text
				var $text6 = $row.find("."+clsNameDOB).text(); // Find the text	
				var $text7 = $row.find("."+clsmobileno).text(); // Find the text	
				$("#modalFirstName").html($text1);
				$("#modalLastName").html($text2);
				$("#modalVoterID").html($text3);
				if($text4 == 'M')
					$("#modalSex").html('Male / &#2346;&#2369;&#2352;&#2369;&#2359; ');
				if($text4 == 'F')
					$("#modalSex").html('Female / &#2360;&#2381;&#2340;&#2381;&#2352;&#2368;');
				$("#modalAge").html($text5);
				$("#modalContact").val($text7);
				$("#modalSectionName").val(SECTION_NO);
				$("#myCandidateModal").modal('show');
			}
		</script>
	</head>
	<?php
		//header("Content-Type:text/html;charset=utf-8");
	?>
<body style="background-color:rgba(210,210,120,0.2);">
	<input type="hidden" id="txtCadId">
	<div class="container">
                <!-- <marquee style="color:red;font-weight:bold;display:none;">
                     <p>For Detail Info Click On Blue Icon.<p>
                     <p style='margin-right:30px;'>&#2344;&#2367;&#2355;&#2366; &#2330;&#2367;&#2344;&#2307; &#2342;&#2366;&#2348;&#2370;&#2344; &#2346;&#2370;&#2352;&#2381;&#2339; &#2350;&#2366;&#2361;&#2367;&#2340;&#2368; &#2346;&#2361;&#2366;&#2357;&#2368;</p>
                 </marquee> -->
        <div class="row">
        </div> 
	<?php
	?>
	<!--	<button class="btn btn-danger pull-right" id="btnFilter" style="margin-top:20px;font-weight:bold;">Search</button>-->
		<h3 class="text-center titlePage" style="color:#000;">Candidate List - &#2350;&#2340;&#2342;&#2366;&#2352; &#2340;&#2325;&#2381;&#2359;&#2358;&#2367;&#2354;
			</h3>
		<button id='openSearchDiv' class="btn btn-info pull-right"><span class='glyphicon glyphicon-search'></button><br>
		<div class="row" style='display:none;' id='searchDiv'>
			<div class="row">
				<div class="col-xs-4">
					<label>SECTION NAME</label>
				</div>
				<div class="col-xs-8">
					<select id="txtSectionName" class="form-control" autofocus></select>
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>AGE</label>
				</div>
				<div class="col-xs-3">
					<select id="txtAGEFROM" class="form-control">
						<option value=''> FROM </option>	
						<?php for($i=1;$i<100;$i++)
						{
							echo "<option value='$i'>$i</option>";
						}?>
					</select>
				</div>
				<div class="col-xs-2">
					FROM 
				</div>
				<div class="col-xs-3">
					<select id="txtAGETO" class="form-control">
						<option value=''> TO </option>	
						<?php for($i=1;$i<100;$i++)
						{
							echo "<option value='$i'>$i</option>";
						}?>
					</select>
				</div>
				<div class="col-xs-1">
					TO 
				</div>
			</div><br>			
			<div class="row">
				<div class="col-xs-4">
					<label>First Name</label>
				</div>
				<div class="col-xs-8">
					<input type="text" id="txtFirstName" class="form-control">
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>Last Name</label>
				</div>
				<div class="col-xs-8">
						<input class="form-control" type="text" id='txtLastName'>
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>Voter Id</label>
				</div>
				<div class="col-xs-8">
					<input type="text" id="txtVoterId" class="form-control">
				</div>				
			</div><br>
			<div class="row">
				<center><button type="button" class="btn btn-primary" id="txtSaveFilter">Search</button></center>
			</div><br>
		</div>
		<div class="row">
			<div id="example_wrapper">
				<div id="showDataDiv" class="table-responsive">
			</div>
		</div>
			<div id='loaderWrapper'><div class="loader"></div></div>
	</body>
</html>
<div class="modal fade" id="myCandidateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document" style='z-index:1000000;'>
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Personal Information - &#2357;&#2376;&#2351;&#2340;&#2381;&#2340;&#2367;&#2325; &#2350;&#2366;&#2361;&#2367;&#2340;&#2368;</h4>
      </div>
      <div class="modal-body">
		<table class='table table-bordered table-responsive table-condensed table-striped'>
			<tr>
				<td>First Name - &#2360;&#2381;&#2357;&#2340;&#2307; &#2344;&#2366;&#2357;</td>
				<td id='modalFirstName'></td>
			</tr>
			<tr>
				<td>Last Name - &#2310;&#2337;&#2344;&#2366;&#2357;</td>
				<td id='modalLastName'></td>
			</tr>
			<tr>
				<td>Voter ID - &#2357;&#2379;&#2335;&#2352; &#2325;&#2381;&#2352;&#2350;&#2366;&#2306;&#2325;</td>
				<td id='modalVoterID'></td>
			</tr>
			<tr>
				<td>Gender - &#2354;&#2367;&#2306;&#2327;</td>
				<td id='modalSex'></td>
			</tr>
			<tr>
				<td>Age - &#2357;&#2351; </td>
				<td id='modalAge'></td>
			</tr>
			<tr>
				<td>Contact - &#2350;&#2379;&#2348;&#2366;&#2312;&#2354; &#2344;.</td>
				<td><input type="number" id="modalContact" class="form-control"></td>
			</tr>
			<tr>
				<td>Section Name - &#2346;&#2381;&#2352;&#2349;&#2366;&#2327; &#2344;&#2366;&#2357; </td>
				<td><select id="modalSectionName" class="form-control" disabled></select></td>
			</tr>			
		</table>
      </div>
      <div class="modal-footer">
		<button type="button" id="modalSave" class="btn btn-default" data-dismiss="modal">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
 <!-- Modal
  <div class="modal fade" id="myModalFilter" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Filter The List</h4>
        </div>
        <div class="modal-body">
          <div class="container">
			<div class="row">
				<div class="col-xs-4">
					<label>SECTION NAME</label>
				</div>
				<div class="col-xs-8">
					<select id="txtSectionName" class="form-control" autofocus></select>
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>AGE</label>
				</div>
				<div class="col-xs-3">
					<select id="txtAGEFROM" class="form-control">
						<option value='0'> FROM </option>	
						<?php for($i=1;$i<100;$i++)
						{
							echo "<option value='$i'>$i</option>";
						}?>
					</select>
				</div>
				<div class="col-xs-2">
					FROM 
				</div>
				<div class="col-xs-3">
					<select id="txtAGETO" class="form-control">
						<option value='0'> TO </option>	
						<?php for($i=1;$i<100;$i++)
						{
							echo "<option value='$i'>$i</option>";
						}?>
					</select>
				</div>
				<div class="col-xs-1">
					TO 
				</div>
			</div><br>			
			<div class="row">
				<div class="col-xs-4">
					<label>First Name</label>
				</div>
				<div class="col-xs-8">
					<input type="text" id="txtFirstName" class="form-control">
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>Last Name</label>
				</div>
				<div class="col-xs-8">
					<input type="text" id="txtLastName" class="form-control">
				</div>				
			</div><br>
			<div class="row">
				<div class="col-xs-4">
					<label>Voter Id</label>
				</div>
				<div class="col-xs-8">
					<input type="text" id="txtVoterId" class="form-control">
				</div>				
			</div><br>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  <button type="button" class="btn btn-primary" id="txtSaveFilter">Search</button>
        </div>
      </div>
    </div>
  </div> -->
</div>
	
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8;">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<link rel="stylesheet prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css">
		<script type="text/javascript" src="js/jquery.min.js"></script>		
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js"></script>
		<style>
		.well{
				background-color:#fff;
			}

		#success_message{ display: none;}
		</style>
		<script>
			  var getUrlParameter = function getUrlParameter(sParam) {
				var sPageURL = decodeURIComponent(window.location.search.substring(1)),
					sURLVariables = sPageURL.split('&'),
					sParameterName,
					i;

				for (i = 0; i < sURLVariables.length; i++) {
					sParameterName = sURLVariables[i].split('=');

					if (sParameterName[0] === sParam) {
						return sParameterName[1] === undefined ? true : sParameterName[1];
					}
				}
			};
		
			  $(document).ready(function() {
			  
						// Use Ajax to submit form data
						$("#formsubmit").click(function(){
							$.post($form.attr('action'),{
								first_name:$("#first_name").val(),
								last_name:$("#last_name").val(),
								comment:$("#comment").val()
							},function(result){
								console.log(result);
								alert(result);
								if(result == 'done'){
										window.location.href = "feedback.php?message="+result;
									}else{
										window.location.href = "feedback.php?message="+result;
									}						
							});
						});
				var tech = getUrlParameter('message');
				$("#success_message").html(tech);
				$('#contact_form').bootstrapValidator({
					feedbackIcons: {
						valid: 'glyphicon glyphicon-ok',
						invalid: 'glyphicon glyphicon-remove',
						validating: 'glyphicon glyphicon-refresh'
					},
					fields: {
						first_name: {
							validators: {
									stringLength: {
									min: 2,
								},
									notEmpty: {
									message: 'Please supply your first name'
								}
							}
						},
						 last_name: {
							validators: {
								 stringLength: {
									min: 2,
								},
								notEmpty: {
									message: 'Please supply your last name'
								}
							}
						},
						comment: {
							validators: {
								  stringLength: {
									min: 10,
									max: 200,
									message:'Please enter at least 10 characters and no more than 200'
								},
								notEmpty: {
									message: 'Please supply a description of your project'
								}
								}
							}
						}
					})
					.on('success.form.bv', function(e) {
						$('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
							$('#contact_form').data('bootstrapValidator').resetForm();

						// Prevent form submission
						e.preventDefault();

						// Get the form instance
						var $form = $(e.target);

						// Get the BootstrapValidator instance
						var bv = $form.data('bootstrapValidator');

					});
			});

		
		</script>
<body>
	<div class="container">
		<form class="well form-horizontal" action="feedbackOperation.php" method="post"  id="contact_form">
	<fieldset>
		<legend>Feedback Us!</legend>

		<div class="form-group">
		  <label class="col-md-4 control-label">First Name</label>  
		  <div class="col-md-4 inputGroupContainer">
		  <div class="input-group">
		  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
		  <input  name="first_name" id="first_name" placeholder="First Name" class="form-control"  type="text">
			</div>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-md-4 control-label" >Last Name</label> 
			<div class="col-md-4 inputGroupContainer">
			<div class="input-group">
		  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
		  <input name="last_name" id="last_name" placeholder="Last Name" class="form-control"  type="text">
			</div>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-md-4 control-label">Description</label>
			<div class="col-md-4 inputGroupContainer">
			<div class="input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
					<textarea class="form-control" name="comment" id="comment" placeholder="Description" rows=7></textarea>
		  </div>
		  </div>
		</div>

		<!-- Success message -->
		<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

		<!-- Button -->
		<div class="form-group">
		  <label class="col-md-4 control-label"></label>
		  <div class="col-md-4">
			<button type="submit"  id="formsubmit"  class="btn btn-warning" >Submit<span class="glyphicon glyphicon-send"></span></button>
		  </div>
		</div>

	</fieldset>
	</form>
	</div>
	</div><!-- /.container -->
</body>
</html>
package com.brucetoo.listvideoplay.model;

/**
 * Created by RAJ on 10/3/2016.
 */
public class Student {
    private String name;
    private String address;
    private String mobile;

    public Student(String name, String address, String mobile) {
        this.name = name;
        this.address = address;
        this.mobile = mobile;
    }
    public String toString(){
        return this.name + " " + this.address + " " + this.mobile;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}

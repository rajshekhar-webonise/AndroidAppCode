package com.brucetoo.listvideoplay.videomanage;

public class Config {

    public static final boolean SHOW_LOGS = true;

}

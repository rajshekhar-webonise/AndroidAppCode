package com.brucetoo.listvideoplay.model;

public class Config
{
    public static final String URL_ADD="http://sample-demo.esy.es/sample/register.php";
    public static final String URL_GET_ALL = "http://sample-demo.esy.es/sample/insert-db.php";
    public static final String URL_GET_EMP = "http://192.168.94.1/Android/CRUD/getEmp.php?id=";
    public static final String URL_UPDATE_EMP = "http://192.168.94.1/Android/CRUD/updateEmp.php";
    public static final String URL_DELETE_EMP = "http://192.168.94.1/Android/CRUD/deleteEmp.php?id=";

    //Keys that will be used to send the request to php scripts
    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAME = "name";
    public static final String KEY_EMP_DESG = "address";
    public static final String KEY_EMP_SAL = "mobile";

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAME = "name";
    public static final String TAG_DESG = "address";
    public static final String TAG_SAL = "mobile";

    //employee id to pass with intent
    public static final String EMP_ID = "id";
}
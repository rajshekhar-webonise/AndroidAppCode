package com.brucetoo.listvideoplay;

import android.app.Application;

/**
 * Created by RAJ on 11/20/2016.
 */
public class CheckInternet extends Application
{

    private String internetStatus;
    private boolean isConnected;

    public String getSessionUser() {
        return sessionUser;
    }

    public void setSessionUser(String sessionUser) {
        this.sessionUser = sessionUser;
    }

    private String sessionUser;
    public boolean isConnection(){
        return isConnected;
    }
    public void setConnected(boolean st){
        this.isConnected = st;
    }
    public String isInternetStatus() {
        return internetStatus;
    }

    public void setInternetStatus(String internetStatus) {
        this.internetStatus = internetStatus;
    }
    private static CheckInternet mInstance;

    @Override
    public void onCreate() {
        super.onCreate();

        mInstance = this;
    }

    public static synchronized CheckInternet getInstance() {
        return mInstance;
    }

    public void setConnectivityListener(ConnectivityReceiver.ConnectivityReceiverListener listener) {
        ConnectivityReceiver.connectivityReceiverListener = listener;
    }
}

package com.brucetoo.listvideoplay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
public class LoginActivity extends AppCompatActivity {
    WebView webView;
    private static RelativeLayout relativeLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        //        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        //android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        //actionBar.setDisplayHomeAsUpEnabled(true);
        webView = (WebView)findViewById(R.id.webView2);
        relativeLayout =(RelativeLayout)findViewById(R.id.relativeLayout1);
        webView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.CLOSE);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setUseWideViewPort(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        Intent i = getIntent();
        //webView.loadUrl("http://sample-demo.esy.es/sample/menu1.html");
        webView.loadUrl("file:///android_asset/menu1.html");
        //checkConnection();
    }
    private boolean checkConnection() {
        boolean isConnected = ConnectivityReceiver.isConnected();
        return isConnected;
    }

    // Showing the status in Snackbar
    private void showSnack(boolean isConnected) {
        String message;
        int color;
        if (isConnected) {
            message = "Good! Connected to Internet";
            color = Color.WHITE;
        } else {
            message = "Sorry! Not connected to internet";
            color = Color.RED;
        }

        Snackbar snackbar = Snackbar
                .make(relativeLayout, message, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(color);
        snackbar.show();
    }
    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        this.finish();
        return super.onKeyDown(keyCode, event);
    }
    private class WebViewClient extends android.webkit.WebViewClient
    {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url)
        {
            boolean got = checkConnection();
            if(got)
            {
               // Toast.makeText(getApplicationContext(),""+url,Toast.LENGTH_SHORT).show();
                if (url.equals("http://sample-demo.esy.es/sample/video")) {
                    Intent intent = new Intent(LoginActivity.this, VideoActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                } else if (url.equals("http://sample-demo.esy.es/sample/profile.html")) {
                    Intent intent = new Intent(LoginActivity.this, UrlActivity.class);
                    intent.putExtra("url", "http://sample-demo.esy.es/sample/profile.html");
                    startActivity(intent);
                } else if (url.equals("http://sample-demo.esy.es/sample/ward12.php")) {
                    Intent intent = new Intent(LoginActivity.this, UrlActivity.class);
                    intent.putExtra("url", "http://sample-demo.esy.es/sample/ward12.php");
                    startActivity(intent);
                } else if (url.equals("http://sample-demo.esy.es/sample/logout")) {
                    Intent intent = new Intent(LoginActivity.this, SwipableTextTabActivity.class);
                    startActivity(intent);
                    return true;
                } else if (url.equals("http://sample-demo.esy.es/sample/feedback.php")) {
                    Intent intent = new Intent(LoginActivity.this, UrlActivity.class);
                    intent.putExtra("url", "http://sample-demo.esy.es/sample/feedback.php");
                    startActivity(intent);
                }
        }else{
                showSnack(got);
            }
            return true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // action with ID action_refresh was selected
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.action_refresh:
                webView.reload();
                break;
            case R.id.action_settings:
                Toast.makeText(this, "Settings selected", Toast.LENGTH_SHORT)
                        .show();
                break;
            default:
                break;
        }
        return  true;
    }
}

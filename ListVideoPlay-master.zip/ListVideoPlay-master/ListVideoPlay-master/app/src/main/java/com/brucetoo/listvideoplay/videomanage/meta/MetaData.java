package com.brucetoo.listvideoplay.videomanage.meta;

/**
 * MetaData to handle data we need when item changed
 */
public interface MetaData {
     //Has more than one VideoPlayerView
     boolean isMorePlayView();
}

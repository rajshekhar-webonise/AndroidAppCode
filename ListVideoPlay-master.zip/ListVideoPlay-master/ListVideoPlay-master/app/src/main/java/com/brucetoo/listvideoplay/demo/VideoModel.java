package com.brucetoo.listvideoplay.demo;

/**
 * Created by Bruce Too
 * On 10/20/16.
 * At 10:14
 */

public class VideoModel {

    public String coverImage;
    public String videoUrl;
    public int position;
}

package com.brucetoo.listvideoplay;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.brucetoo.listvideoplay.model.RequestHandler;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class LoginFragment extends Fragment {

    private EditText nameED,passED;
    private String name,pass;
    private Button login;
    String name1 = new String("a");
    String pass1 = new String("a");
    public String message;
    public boolean connect,internetConnected;
    public ScrollView linearLayout;
    public Snackbar snackbar;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        getActivity().registerReceiver(broadcastReceiver, new IntentFilter("broadCastName"));
        linearLayout = (ScrollView) view.findViewById(R.id.scrollView1);
        nameED =(EditText) view.findViewById(R.id.input_name);
        passED = (EditText) view.findViewById(R.id.input_password);
        login =(Button) view.findViewById(R.id.btn_signup);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (
                        (
                                (
                                        (CheckInternet) getActivity().getApplication()).isConnection()
                        )
                    ){
                        doLogin();
                }else{
                    Snackbar snackbar = Snackbar
                            .make(linearLayout, "No Internet Connected, Try Again !", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });
        return  view;
    }

    @Override
    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(broadcastReceiver);
    }

    BroadcastReceiver broadcastReceiver =  new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            Bundle b = intent.getExtras();

            message = b.getString("message");
            connect = b.getBoolean("connect");
            Log.e("newmesage", "" + message);
        }
    };
    public void callActivity(){
        name = nameED.getText().toString();
        pass = passED.getText().toString();
        if(name1.equals(name) && pass1.equals(pass))
        {
            startActivity(new Intent(getActivity(), UrlActivity.class));
        }
        else {
            Toast.makeText(getActivity(), "" + passED.getText(), Toast.LENGTH_SHORT).show();
        }
    }

    private void doLogin() {

        final String username = nameED.getText().toString().trim();
        final String password = passED.getText().toString().trim();

        class Login extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getActivity(),"Please Wait","Login is under process.!!!",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String ss[] = s.split("-");
                ((CheckInternet) getActivity().getApplication()).setSessionUser(ss[1]);

                if(ss[0].trim().equals("success")){
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                }
                else{
                    Toast.makeText(getActivity(),"Try Again,You went wrong.",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("Flag","login");
                params.put("username",username);
                params.put("password",password);
                RequestHandler rh = new RequestHandler();
                String res = null;
                try {
                    res = rh.sendPostRequest("http://sample-demo.esy.es/sample/docheckUserLogin.php", params);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                return res;
            }
        }
        Login ae = new Login();
        ae.execute();
    }
}

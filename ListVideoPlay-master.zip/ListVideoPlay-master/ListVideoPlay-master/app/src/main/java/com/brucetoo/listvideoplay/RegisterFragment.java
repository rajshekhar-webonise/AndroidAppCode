package com.brucetoo.listvideoplay;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.brucetoo.listvideoplay.model.RequestHandler;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.HashMap;

public class RegisterFragment extends Fragment {
    private EditText edFullName,edSocialActivity,edUserName,edPassword,edConfPass;
    private Button btnRegister,btnDatePicker;
    private int mYear, mMonth, mDay;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);
        edFullName = (EditText) view.findViewById(R.id.txtFullName);
        edSocialActivity = (EditText) view.findViewById(R.id.txtSocialActivity);
        edUserName = (EditText) view.findViewById(R.id.txtUserName);
        edPassword = (EditText) view.findViewById(R.id.txtPassword);
        edConfPass = (EditText) view.findViewById(R.id.txtConfPassword);
        btnRegister = (Button)view.findViewById(R.id.btnRegister);
        edSocialActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePicker();
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isValidate()){
                    doRegister();
                }
            }
        });
        return view;
    }

    private void openDatePicker() {
        DatePickerFragment date = new DatePickerFragment();
        /**
         * Set Up Current Date Into dialog
         */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        date.setArguments(args);
        /**
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);
        date.show(getActivity().getSupportFragmentManager(), "Date Picker");
    }

    DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
           edSocialActivity.setText(String.valueOf(year) + "-" + String.valueOf(monthOfYear)
                    + "-" + String.valueOf(dayOfMonth));
        }
    };

    public boolean isValidate(){
        if(edFullName.getText().toString().equals("") || edFullName.getText().toString().length() == 0){
            edFullName.requestFocus();
            edFullName.setError("Full Name Can Not Be Blank.");
            return false;
        }
        else if(edSocialActivity.getText().toString().equals("") || edSocialActivity.getText().toString().length() == 0){
            edSocialActivity.requestFocus();
            edSocialActivity.setError("Social Activity Can Not Be Blank.");
            return false;
        }
        else if(edUserName.getText().toString().equals("") || edUserName.getText().toString().length() == 0){
            edUserName.requestFocus();
            edUserName.setError("User Name Can Not Be Blank.");
            return false;
        }
        else if(edPassword.getText().toString().equals("") || edPassword.getText().toString().length() == 0){
            edPassword.requestFocus();
            edPassword.setError("Password Can Not Be Blank.");
            return false;
        }
        else if(edConfPass.getText().toString().equals("") || edConfPass.getText().toString().length() == 0){
            edConfPass.requestFocus();
            edConfPass.setError("Confirm Password Can Not Be Blank.");
            return false;
        }
        else if(!edConfPass.getText().toString().equals(edPassword.getText().toString())){
            edConfPass.requestFocus();
            edConfPass.setError("Password And Confirm Be Same.");
            return false;
        }
        else{
            return true;
        }
    }
    private void doRegister() {

        final String fullName = edFullName.getText().toString().trim();
        final String socialActivity = edSocialActivity.getText().toString().trim();
        final String username = edUserName.getText().toString().trim();
        final String password = edPassword.getText().toString().trim();
        final String confpass = edConfPass.getText().toString().trim();

        class Register extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getActivity(),"Please Wait ","Registration is under Process.!!!",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if(s.trim().equals("success")) {
                    edFullName.setText("");
                    edSocialActivity.setText("");
                    edUserName.setText("");
                    edPassword.setText("");
                    edConfPass.setText("");
                }else {
                    Toast.makeText(getActivity(), " Try Again", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("fullname",fullName);
                params.put("DOB",socialActivity);
                params.put("username",username);
                params.put("password",password);
                params.put("confpassword",confpass);

                RequestHandler rh = new RequestHandler();
                String res = null;
                try {
                    res = rh.sendPostRequest("http://sample-demo.esy.es/sample/do-register.php", params);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                return res;
            }
        }

        Register ae = new Register();
        ae.execute();
    }
    private class DatePickerFragment extends DialogFragment {
        DatePickerDialog.OnDateSetListener ondateSet;

        public DatePickerFragment() {
        }

        public void setCallBack(DatePickerDialog.OnDateSetListener ondate) {
            ondateSet = ondate;
        }

        private int year, month, day;

        @Override
        public void setArguments(Bundle args) {
            super.setArguments(args);
            year = args.getInt("year");
            month = args.getInt("month");
            day = args.getInt("day");
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new DatePickerDialog(getActivity(), ondateSet, year, month, day);
        }
    }
}
